
GoogleStoreLocator


Author: Quadro - Jan Dähne info@quadro-system.de
Copyright 2015

Official Documentation: http://www.quadro-system.de/modx-extras/googlestorelocator.html

Bugs and Feature Requests: https://github.com:jdaehne/GoogleStoreLocator

Questions: http://forums.modx.com

Created by MyComponent
